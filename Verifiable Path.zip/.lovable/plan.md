# Decentralized Verification Refactor

Replace the Admin-approval flow with automated rules: trusted institution domains, personal-vs-work email detection for recruiters, and contributor-gated peer reviews. No central approver.

## 1. Database changes (one migration)

**Enums (replace existing):**
- `recruiter_status`: `pending` | `work_email_verified` | `limited` | `company_domain_verified`
- `institution_status`: `email_pending` | `email_verified` | `domain_not_recognized` | `needs_review`
- New `learner_status`: `email_pending` | `verified`
- New `contributor_status`: `verified` | `pending` | `not_contributor`
- New `review_invite_status`: `imported` | `invite_sent` | `pending` | `received` | `not_contributor`

**Modify tables:**
- `learner_profiles` → add `status learner_status default 'email_pending'`
- `recruiter_profiles` → keep `verification_status` but repurpose to new enum; drop admin-only update trigger; allow self-update of status via DB function based on email confirmation
- `institution_profiles` → restructure: `user_id, institution_name, official_email, contact_person_name, contact_person_role, department, website, status, domain`. Public self-signup (insert own row).
- Drop/repurpose `institution_access_requests` → keep table but only used when domain not in trusted list (status `needs_review`); remains insertable by anyone, no admin reads required.

**New tables:**
- `trusted_institution_domains (domain text primary key, institution_name text, created_at)` — seeded with cust.edu.pk, nust.edu.pk, comsats.edu.pk, nu.edu.pk. Public SELECT.
- `project_contributors (id, project_ref text, user_id uuid, source text, status contributor_status, verified_at)` — link verified contributors to projects.
- `review_invitations (id, project_ref, contributor_user_id, contributor_email, status review_invite_status, sent_at, responded_at)` — track invites.

**Drop admin pieces:**
- Remove `'admin'` from `app_role` enum (or leave value but stop using it).
- Drop admin-only RLS policies on recruiter/institution/learner tables.
- Drop `guard_recruiter_verification` trigger.
- Replace with: trigger on `auth.users` email confirmation that promotes learner→verified, recruiter→work_email_verified (if work email) or stays limited, institution→email_verified.

**Email-domain helper SQL function:**
- `is_personal_email(email text) returns boolean` — true for gmail/yahoo/outlook/hotmail/icloud/proton.
- `is_trusted_institution(email text) returns boolean` — checks `trusted_institution_domains`.

## 2. Frontend

**Routes:**
- `/signup` chooser: Learner / Institution / Recruiter cards (institution back to public).
- `/signup/learner` — existing form, unchanged fields.
- `/signup/institution` — NEW form (replaces InstitutionAccessRequest). Validates email domain client-side: if personal email → block with "use official institution email"; if not in trusted list → still creates account but flags `needs_review` and shows the explanatory message.
- `/signup/recruiter` — existing form; if work_email is personal → set status `limited` with banner "Limited Recruiter"; otherwise `pending` until email verified.
- Remove `/admin/*` routes and `AdminDashboard.tsx`.
- Remove `/institution-access` (or redirect to `/signup/institution`).

**Login:** unchanged (already auto-routes by role).

**Wording:** Add the decentralized-trust note on each signup page.

**Status badges:** Use semantic tokens; new `StatusBadge` variants for the new statuses ("Email Verification Pending", "Institution Email Verified", "Limited Recruiter", "Domain Not Recognized", etc.).

**Skill labels:** Search/replace "Expert / Beginner / Intermediate / Final Skill Score" with the new vocabulary in `sijil-data.ts` and any UI string that uses them.

**Peer review gate:** In `pages/learner/PeerReviews.tsx` and `pages/review/ReviewInvite.tsx`, before allowing a review submission, check `project_contributors` for `status='verified'` for the reviewer. Show contributor status badge. If not a contributor, block submission with message.

**Auth context:** Drop `admin` from `pickPrimaryRole` priority; drop admin redirect.

## 3. Files

**Create:**
- `src/pages/signup/InstitutionSignup.tsx`
- `src/lib/email-rules.ts` (personal/trusted helpers, mirrored client-side)

**Edit:**
- `src/App.tsx` (route changes)
- `src/pages/SignupChooser.tsx` (re-add Institution card)
- `src/pages/signup/RecruiterSignup.tsx` (limited-recruiter logic)
- `src/pages/signup/LearnerSignup.tsx` (status note)
- `src/hooks/useAuth.tsx`, `src/lib/auth-helpers.ts` (drop admin)
- `src/components/sijil/StatusBadge.tsx` (new statuses)
- `src/lib/sijil-data.ts` (rename skill labels)
- `src/pages/learner/PeerReviews.tsx`, `src/pages/review/ReviewInvite.tsx` (contributor gating)

**Delete:**
- `src/pages/admin/AdminDashboard.tsx`
- `src/pages/signup/InstitutionAccessRequest.tsx` (replaced)

## 4. Out of scope (this pass)
- Sending real review-invitation emails (table+UI only; wiring to Lovable transactional email can be a follow-up).
- GitHub contributor auto-population beyond what `github_repo_contributors` already provides — surface those as candidates.

## 5. Notes
- Email verification is handled by Supabase auth (`email_confirmed_at`). A DB trigger on `auth.users` flips the status fields automatically — fully decentralized, no admin click.
- Existing dashboards and integrations are preserved.